package com.ffutop.signature;

/**
 * @author fangfeng
 * @since 2019-02-26
 */
public class Main {

    public static void main(String[] args) {
        CountService countService = new CountService();
        countService.add(1);
        System.out.println(String.format("currentValue = %d", countService.getCurrentValue()));
    }
}
