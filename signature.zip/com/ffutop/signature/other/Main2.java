package com.ffutop.signature.other;
import com.ffutop.signature.CountService;

/**
 * @author fangfeng
 * @since 2019-02-27
 */
public class Main2 {

    public static void main(String[] args) {
        CountService countService = new CountService();
        System.out.println(String.format("currentValue = %d", countService.add(1)));
    }
}
