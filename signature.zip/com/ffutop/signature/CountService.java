package com.ffutop.signature;

/**
 * @author fangfeng
 * @since 2019-02-26
 */
public class CountService {

    private int currentValue = 0;

    public void add(int addend) {
        currentValue += addend;
    }

    public int getCurrentValue() {
        return currentValue;
    }
}
