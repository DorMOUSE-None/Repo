package com.ffutop.signature.support;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.*;

import static org.objectweb.asm.ClassReader.SKIP_DEBUG;

/**
 * @author fangfeng
 * @since 2019-02-26
 */
public class Generator {

    private static final String path = "/Users/fangfeng/WorkPkg/lab/src/main/java/com/ffutop/signature/CountService.class";

    public static void main(String[] args) throws IOException {
        DataInputStream dis = new DataInputStream(new FileInputStream(path));
        ClassReader cr = new ClassReader(dis);
        dis.close();
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "add", "(I)I", null, null);
        cr.accept(cw, SKIP_DEBUG);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitInsn(Opcodes.DUP);
        mv.visitFieldInsn(Opcodes.GETFIELD, "com/ffutop/signature/CountService", "currentValue", "I");
        mv.visitVarInsn(Opcodes.ILOAD, 1);
        mv.visitInsn(Opcodes.IADD);
        mv.visitInsn(Opcodes.DUP);
        mv.visitVarInsn(Opcodes.ISTORE, 1);
        mv.visitFieldInsn(Opcodes.PUTFIELD, "com/ffutop/signature/CountService", "currentValue", "I");
        mv.visitVarInsn(Opcodes.ILOAD, 1);
        mv.visitInsn(Opcodes.IRETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
        DataOutputStream dos = new DataOutputStream(new FileOutputStream(path));
        dos.write(cw.toByteArray());
        dos.flush();
        dos.close();
    }
}
