package me.fangfeng.javaagent;

import me.fangfeng.client.Rand;

import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;

/**
 * Agent - 代理
 *
 * 基于 JVM TI (JVM Tool Interface) 实现的 Java ClassFile 的增强
 *
 * {@link Agent#premain(String, Instrumentation)} 和 {@link Agent#agentmain(String, Instrumentation)}
 *
 *
 * @author fangfeng
 * @since 2018/8/7
 */
public class Agent {

    public static void premain(String args, Instrumentation instrumentation) {
        ClassTimer transformer = new ClassTimer();
        instrumentation.addTransformer(transformer);
    }

    public static void agentmain(String args, Instrumentation instrumentation) throws UnmodifiableClassException {
        System.out.println("SUCCESS AGENTMAIN");
        ClassTimer transformer = new ClassTimer();
        instrumentation.addTransformer(transformer, true);
        instrumentation.retransformClasses(Rand.class);
    }
}
