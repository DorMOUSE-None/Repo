package me.fangfeng.javaagent;

import com.sun.tools.attach.AgentInitializationException;
import com.sun.tools.attach.AgentLoadException;
import com.sun.tools.attach.AttachNotSupportedException;
import com.sun.tools.attach.VirtualMachine;

import java.io.IOException;

/**
 * @author fangfeng
 * @since 2018/8/7
 */
public class Main {

    public static void main(String[] args) throws IOException, AttachNotSupportedException, AgentLoadException, AgentInitializationException {
        VirtualMachine vm = null;
        try {
            vm = VirtualMachine.attach("29456");
            vm.loadAgent("/Users/fangfeng/WorkPkg/lab/src/main/java/agent.jar");
        } finally {
            if (vm != null) {
                vm.detach();
            }
        }
    }
}
