package me.fangfeng.client;

/**
 * @author fangfeng
 * @since 2018/8/7
 */
public class Rand {

    public void run() {
        while (true) {
            double rand = Math.random();
            if (rand > 0.995) {
                System.out.println(String.format("get random, values %f", rand));
                return;
            }
        }
    }

}
