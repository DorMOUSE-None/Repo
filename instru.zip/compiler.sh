#!/bin/bash

# 编译 me.fangfeng.javaagent 包下的类
javac -cp .:/Users/fangfeng/.m2/repository/org/ow2/asm/asm/6.1.1/asm-6.1.1.jar me/fangfeng/javaagent/Agent.java me/fangfeng/javaagent/ClassTimer.java me/fangfeng/javaagent/MyClassWriter.java me/fangfeng/javaagent/MyMethodWriter.java me/fangfeng/javaagent/StaticTimer.java

# 打包 me.fangfeng.javaagent 的 .class -> agent.jar
jar cvfm agent.jar MANIFEST-agent.MF me/fangfeng/javaagent/Agent.class me/fangfeng/javaagent/ClassTimer.class me/fangfeng/javaagent/MyClassWriter.class me/fangfeng/javaagent/MyMethodWriter.class me/fangfeng/javaagent/StaticTimer.class

# 编译 me.fangfeng.client 包下的类
javac me/fangfeng/client/Main.java me/fangfeng/client/Rand.java

# 以 me.fangfeng.client.Main 作为主类启动
java -javaagent:agent.jar me.fangfeng.client.Main

# jar cvfm agent.jar META-INF/MANIFEST.MF me/fangfeng/javaagent/Agent.class me/fangfeng/javaagent/ClassLogger.class me/fangfeng/javaagent/MyClassWriter.class me/fangfeng/javaagent/MyMethodWriter.class

# jar cvfm app.jar manifast4app me/fangfeng/client/Code.class me/fangfeng/client/Example.class me/fangfeng/client/StaticTimer.class

#java -javaagent:agent.jar -jar app.jar
# java -javaagent:agent.jar me/fangfeng/client/Example
