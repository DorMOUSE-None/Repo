
#include "Main.h"

JNIEXPORT void JNICALL Java_Main_sayHi (JNIEnv *env, jobject jobj, jstring jstr)
{
    const char *str = (*env)->GetStringUTFChars(env, jstr, 0);
    int len = (*env)->GetStringUTFLength(env, jstr);
    printf("%p\n", str);
#ifdef SUCCESS
    (*env)->ReleaseStringUTFChars(env, jstr, str);
#endif
    return ;
}
